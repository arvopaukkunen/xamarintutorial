namespace Greetings

open Xamarin.Forms

type App() = 
    inherit Application(MainPage = GreetingsPage())

